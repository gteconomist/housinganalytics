// build-analysis-geo.mjs — NATIONAL
// Pulls ACS 2020-2024 5-yr cost-burden + supply tables for every county and every
// profiled city (the 4,814 places in manifest.json, i.e. 5,000+ population), stores
// RAW counts per geography (affordability math runs client-side), and bundles one
// file per state into public/analysis-data/. Also emits a compact per-geography
// summary (src/data/housing-gap-summary.json — committed, unlike src/data/generated/) so
// profile pages can render the gap card at build time without fetching a state bundle.
//
// Env: CENSUS_API_KEY (falls back to repo-root .env), STATES (comma FIPS; default =
// every state in manifest.json), CONCURRENCY (default 6).
import { writeFileSync, mkdirSync, readFileSync, existsSync } from 'node:fs';
import { fileURLToPath } from 'node:url';
import { dirname, resolve as _resolve } from 'node:path';

const __dirname = dirname(fileURLToPath(import.meta.url));
const ROOT = _resolve(__dirname, '..');
const OUT = _resolve(ROOT, 'public/analysis-data');
const GEN = _resolve(ROOT, 'src/data/generated');

// --- API key: env, else repo-root .env ---
let KEY = process.env.CENSUS_API_KEY;
if (!KEY && existsSync(_resolve(ROOT, '.env'))) {
  const m = /^\s*CENSUS_API_KEY\s*=\s*"?([^"\s]+)"?/m.exec(readFileSync(_resolve(ROOT, '.env'), 'utf8'));
  if (m) KEY = m[1];
}

const YEAR = 2024; // ACS 2020-2024 5-yr — matches the rest of the site (CHAS layered separately)
const CONCURRENCY = Number(process.env.CONCURRENCY || 6);

const MANIFEST = JSON.parse(readFileSync(_resolve(GEN, 'manifest.json'), 'utf8'));
// Only build for places that actually have a profile on the site (5,000+ pop).
const PLACE_KEEP = new Set(MANIFEST.places.map((p) => p.geoid));
const ALL_STATES = [...new Set(MANIFEST.counties.map((c) => c.geoid.slice(0, 2)))].sort();
const STATES = (process.env.STATES ? process.env.STATES.split(',').map((s) => s.trim().padStart(2, '0')) : ALL_STATES);

// Tables we pull whole (group()) then slice by known offsets.
const TABLES = ['B25074', 'B25095', 'B25118', 'B25063', 'B25075', 'B25003', 'B19013', 'B25064', 'B25077', 'B25122', 'B19037'];

const num = (v) => { const n = Number(v); return (v == null || !Number.isFinite(n) || n <= -666666666) ? 0 : n; };
const sleep = (ms) => new Promise((z) => setTimeout(z, ms));

async function pull(table, forC, inC) {
  const p = new URLSearchParams();
  p.set('get', `group(${table})`); p.set('for', forC); if (inC) p.set('in', inC); p.set('key', KEY);
  const url = `https://api.census.gov/data/${YEAR}/acs/acs5?${p}`;
  let lastErr = null;
  for (let a = 0; a < 6; a++) {
    try {
      const r = await fetch(url);
      if (r.status === 204) return [];          // no such geography at this level
      if (r.ok) return await r.json();
      if (r.status === 400) {                    // table genuinely unavailable for this geo
        const t = await r.text();
        if (/unknown variable|error: unknown/i.test(t)) return [];
      }
      lastErr = new Error(`HTTP ${r.status}`);
    } catch (e) { lastErr = e; }
    await sleep(500 * (a + 1));
  }
  throw new Error(`fetch failed ${table} ${forC} ${inC || ''}: ${lastErr && lastErr.message}`);
}

// pull one table for all geographies of one level in a state -> Map geoid->{NAME, vars}
async function pullLevel(table, level, st) {
  const forC = level === 'place' ? 'place:*' : 'county:*';
  const json = await pull(table, forC, `state:${st}`);
  const out = new Map();
  if (!json.length) return out;
  const h = json[0];
  const si = h.indexOf('state'), pi = h.indexOf(level), ni = h.indexOf('NAME');
  for (const row of json.slice(1)) {
    const geoid = row[si] + row[pi];
    if (level === 'place' && !PLACE_KEEP.has(geoid)) continue;   // profiled cities only
    const rec = {};
    h.forEach((k, i) => { if (k.endsWith('E')) rec[k] = row[i]; });
    out.set(geoid, { name: row[ni], vars: rec });
  }
  return out;
}

// run async jobs with a small concurrency cap
async function mapLimit(items, limit, fn) {
  const out = new Array(items.length);
  let i = 0;
  await Promise.all(Array.from({ length: Math.min(limit, items.length) }, async () => {
    while (i < items.length) { const k = i++; out[k] = await fn(items[k], k); }
  }));
  return out;
}

// --- model builder from raw vars for one geography ---
const V = (vars, t, i) => num(vars[`${t}_${String(i).padStart(3, '0')}E`]);
const REN_STARTS = [2, 11, 20, 29, 38, 47, 56];          // B25074 income brackets
const OWN_STARTS = [2, 11, 20, 29, 38, 47, 56, 65];      // B25095 income brackets
const B122_BASES = [2, 19, 36, 53, 70, 87, 104];         // B25122 income brackets (each: +1 with-cash-rent, +2..+15 rent bands, +16 no cash rent)
function burdenTriplet(vars, table, starts) {
  const total = [], burd = [], sev = [];
  for (const s of starts) {
    total.push(Math.round(V(vars, table, s)));
    burd.push(Math.round(V(vars, table, s + 4) + V(vars, table, s + 5) + V(vars, table, s + 6) + V(vars, table, s + 7)));
    sev.push(Math.round(V(vars, table, s + 7)));
  }
  return { total, burd, sev };
}
// ── WAHI — working-age household income (ACS B19037) ─────────────────────────
// Median income of households HEADED by someone 25–64. It is NOT "the income of
// prime working-age adults": ACS classifies a whole household by the age of its
// reference person, so a 70-year-old still working is excluded, and a retired
// parent living in a 45-year-old's household is counted in full. Say so wherever
// this number is published.
//
// Method: pool the 25–44 and 45–64 bracket counts and take the median by linear
// interpolation inside the containing bracket — the same method Census uses for
// B19013. The open top bracket ($200k+) is modelled at $200k–$400k and flagged.
const B19037_EDGES = [[0, 10000], [10000, 15000], [15000, 20000], [20000, 25000], [25000, 30000],
  [30000, 35000], [35000, 40000], [40000, 45000], [45000, 50000], [50000, 60000], [60000, 75000],
  [75000, 100000], [100000, 125000], [125000, 150000], [150000, 200000], [200000, 400000]];
const B19037_BASE = { u25: 3, a2544: 20, a4564: 37, a65: 54 };   // first bracket variable of each cohort
const B19037_TOT = { u25: 2, a2544: 19, a4564: 36, a65: 53 };    // cohort totals
const cohortB = (vars, base) => Array.from({ length: 16 }, (_, i) => V(vars, 'B19037', base + i));

function medianFromBrackets(counts) {
  const n = counts.reduce((a, b) => a + b, 0);
  if (!(n > 0)) return null;
  const half = n / 2;
  let cum = 0;
  for (let i = 0; i < counts.length; i++) {
    if (counts[i] > 0 && cum + counts[i] >= half) {
      const [lo, hi] = B19037_EDGES[i];
      return { med: lo + (half - cum) / counts[i] * (hi - lo), top: i === 15 };
    }
    cum += counts[i];
  }
  return null;
}

function wahiBlock(vars) {
  const tot = V(vars, 'B19037', 1);
  if (!(tot > 0)) return {};
  const b2544 = cohortB(vars, B19037_BASE.a2544), b4564 = cohortB(vars, B19037_BASE.a4564);
  const bu25 = cohortB(vars, B19037_BASE.u25), b65 = cohortB(vars, B19037_BASE.a65);
  const pooled = b2544.map((x, i) => x + b4564[i]);
  const w = medianFromBrackets(pooled);
  if (!w) return {};
  // The ratio's denominator is interpolated from the SAME table by the SAME method,
  // NOT taken from published B19013. Grouped-data interpolation error runs ±4–7% per
  // median but largely CANCELS in the ratio; mixing the two sources reintroduces it.
  const all = pooled.map((x, i) => x + bu25[i] + b65[i]);
  const m = medianFromBrackets(all);
  const nWork = V(vars, 'B19037', B19037_TOT.a2544) + V(vars, 'B19037', B19037_TOT.a4564);
  return {
    wahi: Math.round(w.med),
    wahiRatio: m && m.med > 0 ? +(w.med / m.med).toFixed(3) : null,
    wahiN: Math.round(nWork),
    s65: +(V(vars, 'B19037', B19037_TOT.a65) / tot * 100).toFixed(1),
    su25: +(V(vars, 'B19037', B19037_TOT.u25) / tot * 100).toFixed(1),
    // Reliability: small geographies make a 64-cell cross-tab far too thin to trust.
    // Under 1,000 households the ratio's p90 blows out from 1.25 to 1.42.
    wahiRel: (nWork >= 500 && tot >= 1000 && !w.top) ? 1 : 0,
  };
}

function buildModel(vars) {
  const ren = burdenTriplet(vars, 'B25074', REN_STARTS);
  const own = burdenTriplet(vars, 'B25095', OWN_STARTS);
  const rentBands = []; for (let i = 3; i <= 26; i++) rentBands.push(Math.round(V(vars, 'B25063', i)));  // B25063 003..026
  const valBands = []; for (let i = 2; i <= 27; i++) valBands.push(Math.round(V(vars, 'B25075', i)));    // B25075 002..027
  const ownInc = []; for (let i = 3; i <= 13; i++) ownInc.push(Math.round(V(vars, 'B25118', i)));        // B25118 003..013
  // B25122 — renter household income x GROSS RENT. Bases 002/019/036/053/070/087/104 are the
  // 7 income brackets (same edges as B25074); base+2 .. base+15 are the 14 "with cash rent"
  // bands. This is the only ACS cross-tab of occupant income by rent level, and it is what
  // makes "affordable AND available" computable outside CHAS. Grid[income][rentBand].
  const rentByInc = B122_BASES.map((s) => {
    const row = []; for (let j = 2; j <= 15; j++) row.push(Math.round(V(vars, 'B25122', s + j)));
    return row;
  });
  return {
    mhi: Math.round(V(vars, 'B19013', 1)),
    ...wahiBlock(vars),
    medRent: Math.round(V(vars, 'B25064', 1)),
    medValue: Math.round(V(vars, 'B25077', 1)),
    tenure: { total: Math.round(V(vars, 'B25003', 1)), owner: Math.round(V(vars, 'B25003', 2)), renter: Math.round(V(vars, 'B25003', 3)) },
    ren, own, rentBands, valBands, ownInc, rentByInc,
  };
}

// ── summary math — mirrors public/js/housing-gap.js at its DEFAULT assumptions ──
const DEFAULTS = { rate: 0.067, down: 0.10, ti: 0.015, pmi: 0.005, front: 0.30 };
const REN_INC_B = [[0, 10000], [10000, 20000], [20000, 35000], [35000, 50000], [50000, 75000], [75000, 100000], [100000, Infinity]];
const RENT_BANDS_B = [[0, 99], [100, 149], [150, 199], [200, 249], [250, 299], [300, 349], [350, 399], [400, 449], [450, 499],
  [500, 549], [550, 599], [600, 649], [650, 699], [700, 749], [750, 799], [800, 899], [900, 999],
  [1000, 1249], [1250, 1499], [1500, 1999], [2000, 2499], [2500, 2999], [3000, 3499], [3500, 6000]];
const REN_TIERS = [20000, 35000, 50000, 75000];   // fallback only
const AMI_TIERS = [0.30, 0.50, 0.80, 1.20];
function cumLE(bands, counts, X) {
  let t = 0;
  for (let i = 0; i < bands.length; i++) {
    const [lo, hi] = bands[i], n = counts[i] || 0;
    if (hi <= X) t += n;
    else if (lo > X) continue;
    else t += n * Math.max(0, Math.min(1, (X - lo) / (hi - lo + 1)));
  }
  return t;
}
const sum = (a) => a.reduce((x, y) => x + (y || 0), 0);

// ── workforce band (80–120% HUD AMI, 4-person) — mirrors public/js/housing-gap.js ──
// The renter-income top bracket is open-ended ($100k+); interpolating inside it is
// unavoidable once 120% AMI clears $100k, so we model it as $100k–$250k rather than
// letting cumLE's Infinity silently drop every household above $100k.
const TOP_INC = 300000;
const REN_INC_CAP = REN_INC_B.map(([lo, hi]) => [lo, Number.isFinite(hi) ? hi : TOP_INC]);
// B25122 rent bands (coarser than B25063; the $2,000+ band is open-ended — capped at $4,000).
const B122_BANDS = [[0, 99], [100, 199], [200, 299], [300, 399], [400, 499], [500, 599], [600, 699],
  [700, 799], [800, 899], [900, 999], [1000, 1249], [1250, 1499], [1500, 1999]];   // 13 closed bands
const B122_TOP = 2000;                                                             // 14th band is "$2,000 or more"
const inBand = (bands, counts, lo, hi) => cumLE(bands, counts, hi) - cumLE(bands, counts, lo);

// B25122's top rent band is open-ended at $2,000+, which swallows the whole workforce range in
// expensive metros. Use B25063's finer $2,000+ shape ([2000,2499]…[3500,6000]) to work out what
// share of that open band falls inside [lo,hi], then apply it to each income bracket.
function topBandShare(rentBands, lo, hi) {
  if (hi <= B122_TOP) return 0;
  const tail = RENT_BANDS_B.map((b, i) => (b[0] >= B122_TOP ? [b, rentBands[i] || 0] : null)).filter(Boolean);
  const tb = tail.map((x) => x[0]), tc = tail.map((x) => x[1]);
  const denom = tc.reduce((a, b) => a + b, 0);
  if (!denom) return 1;                       // no tail detail — treat the open band as fully in range
  return Math.max(0, Math.min(1, inBand(tb, tc, Math.max(lo, B122_TOP), hi) / denom));
}

// Affordable AND available in the workforce band. B25063 (fine rent bands) supplies the
// affordable COUNT; B25122 (income x rent) supplies only the availability RATIO — the share
// of band-rent units NOT already occupied by households above the 120% AMI ceiling. Using
// B25122 as a ratio rather than a count keeps the headline on the finer rent distribution.
// TWO ANCHORS, DELIBERATELY — see public/js/housing-gap.js. HUD AMI is a regulatory threshold
// (regional, family-based, 4-person, capped/floored); local MHI is descriptive (this jurisdiction,
// all households). They disagree on the SIGN of the gap in 26% of geographies and by >2x in 41%.
function workforceBand(model, A, lo, hi) {
  if (!model.rentByInc || !(hi > lo)) return null;
  const rLo = A.front * lo / 12, rHi = A.front * hi / 12;
  const hh = inBand(REN_INC_CAP, model.ren.total, lo, hi);
  const affordable = inBand(RENT_BANDS_B, model.rentBands, rLo, rHi);
  const tShare = topBandShare(model.rentBands, rLo, rHi);
  const perInc = model.rentByInc.map((row) =>
    inBand(B122_BANDS, row.slice(0, 13), rLo, Math.min(rHi, B122_TOP)) + (row[13] || 0) * tShare);
  const tot122 = sum(perInc);
  // households above the ceiling, by their income bracket's share above `hi`
  let above = 0;
  perInc.forEach((n, i) => {
    const [bl, bh] = REN_INC_CAP[i];
    const leShare = bh <= hi ? 1 : (bl > hi ? 0 : Math.max(0, Math.min(1, (hi - bl) / (bh - bl + 1))));
    above += n * (1 - leShare);
  });
  const availRatio = tot122 > 0 ? Math.max(0, Math.min(1, 1 - above / tot122)) : 1;   // no B25122 units in the window (tiny geos): no availability discount
  const available = availRatio == null ? null : affordable * availRatio;
  return {
    lo: Math.round(lo), hi: Math.round(hi), rLo, rHi,
    hh: Math.round(hh),
    affordable: Math.round(affordable),
    available: available == null ? null : Math.round(available),
    availRatio,
    ratioNA: tot122 === 0,
    topModeled: hi > 100000,
    shortage: available == null ? null : Math.round(hh - available),
  };
}

// Anchor A — HUD AMI: what housing PROGRAMS target (LIHTC, HOME, CDBG, inclusionary zoning).
function workforce(model, A) {
  const ami = model.ami;
  if (!ami || !ami.a80 || !ami.a120) return null;
  return workforceBand(model, A, ami.a80, ami.a120);
}
// Anchor B — local median household income: what RESIDENTS actually experience.
function workforceLocal(model, A) {
  if (!model.mhi || model.mhi <= 0) return null;
  return workforceBand(model, A, model.mhi * 0.8, model.mhi * 1.2);
}
// Anchor C — WAHI, working-age household income: what the local WORKFORCE earns, with
// retiree- and student-headed households removed from the median. Published everywhere,
// not as an exception flag: WAHI exceeds MHI in nearly every community (national median
// 1.16×), and the SIZE of that gap does not predict whether it changes the answer —
// re-anchoring flips the sign of the gap in ~10% of geographies in EVERY ratio band,
// including below-average ones. What moves the gap is the band shifting up 10–16% and
// landing in a thin part of the local rent distribution.
function workforceWorking(model, A) {
  if (!model.wahi || model.wahi <= 0) return null;
  return workforceBand(model, A, model.wahi * 0.8, model.wahi * 1.2);
}

function summarize(model) {
  const A = DEFAULTS;
  const renT = sum(model.ren.total), renB = sum(model.ren.burd), renS = sum(model.ren.sev);
  // Price points run on the AMI ladder where HUD AMI is known (mirrors renTiers() in the client);
  // fixed dollar tiers only where it isn't.
  const tiers = (model.ami && model.ami.ami)
    ? AMI_TIERS.map((p) => ({ cut: Math.round(model.ami.ami * p), pctAmi: p }))
    : REN_TIERS.map((c) => ({ cut: c, pctAmi: null }));
  let peak = null;
  for (const t of tiers) {
    const hh = cumLE(REN_INC_CAP, model.ren.total, t.cut);   // capped top bracket — AMI tiers routinely clear $100k
    const units = cumLE(RENT_BANDS_B, model.rentBands, A.front * t.cut / 12);
    const gap = Math.round(hh - units);
    if (!peak || gap > peak.gap) peak = { cut: t.cut, pctAmi: t.pctAmi, gap };
  }
  const c = model.chas;
  const w = workforce(model, A);
  const wl = workforceLocal(model, A);
  const ww = workforceWorking(model, A);
  const ratio = (model.ami && model.ami.ami && model.mhi > 0) ? model.ami.ami / model.mhi : null;
  const bandShare = (w && renT > 0) ? w.hh / renT : null;
  return {
    rt: renT,                                                   // renter HOUSEHOLDS (ACS 2020–2024; B25074 universe = renter-occupied units)
    crt: c ? c.renterTotal : null,                               // renter households (CHAS 2018–2022)
    rb: renT ? +(renB / renT * 100).toFixed(1) : null,           // % renter households cost-burdened
    rbn: renB,                                                   // count of cost-burdened renter households
    rs: renS,                                                    // severely burdened renter households
    rsp: renT ? +(renS / renT * 100).toFixed(1) : null,          // % severely burdened
    pg: peak ? peak.gap : null, pc: peak ? peak.cut : null,      // peak rental gap + its income tier
    pcp: peak ? peak.pctAmi : null,                              // that tier as a share of AMI (null = dollar fallback)
    eli: c && c.eli ? c.eli.shortage : null,                     // CHAS affordable-and-available shortage
    vli: c && c.vli ? c.vli.shortage : null,
    li: c && c.li ? c.li.shortage : null,
    // workforce band, 80–120% HUD AMI (4-person), at DEFAULT assumptions
    wlo: w ? w.lo : null, whi: w ? w.hi : null,
    whh: w ? w.hh : null, wav: w ? w.available : null, wsh: w ? w.shortage : null,
    // same calculation anchored on LOCAL median household income — never publish one without the other
    mlo: wl ? wl.lo : null, mhii: wl ? wl.hi : null,
    mhh: wl ? wl.hh : null, mav: wl ? wl.available : null, msh: wl ? wl.shortage : null,
    // ...and anchored on WAHI — working-age household income (households headed 25–64)
    xlo: ww ? ww.lo : null, xhi: ww ? ww.hi : null,
    xhh: ww ? ww.hh : null, xav: ww ? ww.available : null, xsh: ww ? ww.shortage : null,
    wahi: model.wahi ?? null,
    wr: model.wahiRatio ?? null,        // WAHI / MHI, both interpolated from B19037
    s65: model.s65 ?? null,             // % of households headed 65+
    su25: model.su25 ?? null,           // % of households headed under 25
    wrel: model.wahiRel ?? 0,           // 1 = passes the thin-cross-tab reliability screen
    // How far the WAHI anchor moves the answer, per 1,000 renter households. NEVER express
    // this as a % of the MHI-anchored gap: that gap is frequently near zero, so the
    // percentage is unstable and produces absurd headline numbers (Muscogee GA reads as a
    // "507% move" on +325 → +1,974, which is really 41 units per 1,000 renters).
    xd1k: (ww && wl && ww.shortage != null && wl.shortage != null && renT > 0)
      ? +((ww.shortage - wl.shortage) / renT * 1000).toFixed(1) : null,
    amiRatio: ratio == null ? null : +ratio.toFixed(2),          // HUD AMI / local MHI
    bandShare: bandShare == null ? null : +(bandShare * 100).toFixed(1),  // % of local renters inside the AMI band
    // divergence flag — opposite conclusions, or an AMI far from local incomes (~29% of geographies)
    dvg: ((w && wl && w.shortage != null && wl.shortage != null && (w.shortage > 0) !== (wl.shortage > 0))
      || (ratio != null && (ratio > 2.0 || ratio < 0.80))) ? 1 : 0,
  };
}

// Rank + band each universe on the ≤50% AMI shortage per renter household. The
// denominator is CHAS's OWN renter total, not the ACS one — mixing vintages
// (CHAS 2018–2022 numerator ÷ ACS 2020–2024 denominator) produces impossible
// rates in places whose renter base moved between the two.
const THIN_RENTERS = 500;   // below this, flag the card rather than trusting the rate
function rankUniverse(recs) {
  const scored = Object.entries(recs)
    .filter(([, s]) => s.vli != null && s.crt > 0)
    .map(([gid, s]) => ({ gid, rate: s.vli / s.crt }))
    .sort((a, b) => b.rate - a.rate);
  const n = scored.length;
  scored.forEach((x, i) => {
    const rec = recs[x.gid];
    rec.rank = i + 1;
    rec.score = Math.max(0, Math.min(100, Math.round((1 - i / n) * 100)));
    if (rec.crt < THIN_RENTERS) rec.thin = 1;
  });
  return n;
}

function stripState(n) { return (n || '').replace(/,\s*[^,]+$/, '').trim(); }

function writeSummary(summary) {
  summary.counties_count = rankUniverse(summary.counties);
  summary.places_count = rankUniverse(summary.places);
  summary.vintage = { acs: 'ACS 2020–2024 5-year', chas: 'HUD CHAS 2018–2022' };
  summary.assumptions = DEFAULTS;
  summary.thin_renters = THIN_RENTERS;
  writeFileSync(_resolve(ROOT, 'src/data/housing-gap-summary.json'), JSON.stringify(summary));
  console.log(`Summary: ${summary.counties_count} ranked counties, ${summary.places_count} ranked places.`);
}

// SUMMARY_ONLY=1 — recompute the profile-card summary from the state bundles
// already on disk (no API calls). Use after changing the summary/band math.
function summaryOnly() {
  const summary = { places: {}, counties: {} };
  for (const st of STATES) {
    const f = _resolve(OUT, `states/${st}.json`);
    if (!existsSync(f)) { console.warn(`  ${st}: bundle missing — skipped`); continue; }
    const b = JSON.parse(readFileSync(f, 'utf8'));
    for (const [gid, r] of Object.entries(b.places || {})) summary.places[gid] = summarize(r.model);
    for (const [gid, r] of Object.entries(b.counties || {})) summary.counties[gid] = summarize(r.model);
  }
  writeSummary(summary);
}

async function run() {
  if (process.env.SUMMARY_ONLY) return summaryOnly();
  if (!KEY) throw new Error('CENSUS_API_KEY not set (env or repo-root .env)');
  let CHAS = {};
  const chasPath = _resolve(GEN, 'chas.json');
  if (existsSync(chasPath)) { try { CHAS = JSON.parse(readFileSync(chasPath, 'utf8')).geos || {}; console.log(`CHAS: merged ${Object.keys(CHAS).length} geos`); } catch (e) { console.warn('CHAS load failed:', e.message); } }
  else console.log('CHAS: chas.json not found — bundles built ACS-only');

  // ---- HUD AMI (Section 8 income limits, written by `npm run hud`) ----
  // County-keyed; places inherit their county's HUD metro FMR area via the master
  // crosswalk. Drives the 80–120% AMI workforce band on the KPI cards.
  let HUDAMI = {}, AMIX = {};
  const amiPath = _resolve(GEN, 'hud-ami.json');
  if (existsSync(amiPath)) {
    try {
      HUDAMI = JSON.parse(readFileSync(amiPath, 'utf8'));
      AMIX = JSON.parse(readFileSync(_resolve(__dirname, '.master-crosswalk/crosswalk-places.json'), 'utf8'));
      console.log(`HUD AMI: ${Object.keys(HUDAMI).length} counties`);
    } catch (e) { console.warn('HUD AMI load failed:', e.message); }
  } else console.log('HUD AMI: hud-ami.json not found — run `npm run hud` first; workforce band will be omitted');
  let amiMiss = 0;
  // The band is ANCHORED ON HUD'S PUBLISHED 4-person 80% (low-income) limit, and the implied
  // area median is that limit / 0.8. Do NOT anchor on HUD's raw MFI: the published 80% limit
  // carries HUD's high-housing-cost adjustment (NY, SF, Miami) and its rural/state floors, so
  // in 237 counties it lands at or above 100% of MFI — and in 50 of those, 0.8*limit > 1.2*MFI,
  // which inverts the band. Deriving the band from the limit is self-consistent everywhere.
  const buildAmi = (gid, level) => {
    const cfips = level === 'place' ? (AMIX[gid] && AMIX[gid].county_fips) : gid;
    const a = cfips ? HUDAMI[cfips] : null;
    const l80 = a && (a.ami_80_4p != null ? a.ami_80_4p : (a.mfi_4p != null ? a.mfi_4p * 0.8 : null));
    if (!l80) { amiMiss++; return null; }
    return {
      area: a.fmr_area || null,
      mfi4: a.mfi_4p != null ? Math.round(a.mfi_4p) : null,   // HUD's raw median family income, for reference
      l80: Math.round(l80),                                    // HUD published 4-person 80% limit
      ami: Math.round(l80 / 0.8),                              // implied 100% AMI
      a80: Math.round(l80),                                    // workforce floor
      a120: Math.round(l80 * 1.5),                             // workforce ceiling = 120% of implied AMI
    };
  };

  // ---- Market overlay (Zillow ZORI rent via metro/CBSA + Redfin price by name) ----
  const FIPS_USPS = { '01': 'AL', '02': 'AK', '04': 'AZ', '05': 'AR', '06': 'CA', '08': 'CO', '09': 'CT', '10': 'DE', '11': 'DC', '12': 'FL', '13': 'GA', '15': 'HI', '16': 'ID', '17': 'IL', '18': 'IN', '19': 'IA', '20': 'KS', '21': 'KY', '22': 'LA', '23': 'ME', '24': 'MD', '25': 'MA', '26': 'MI', '27': 'MN', '28': 'MS', '29': 'MO', '30': 'MT', '31': 'NE', '32': 'NV', '33': 'NH', '34': 'NJ', '35': 'NM', '36': 'NY', '37': 'NC', '38': 'ND', '39': 'OH', '40': 'OK', '41': 'OR', '42': 'PA', '44': 'RI', '45': 'SC', '46': 'SD', '47': 'TN', '48': 'TX', '49': 'UT', '50': 'VT', '51': 'VA', '53': 'WA', '54': 'WV', '55': 'WI', '56': 'WY', '72': 'PR' };
  const mNormKey = (region, st) => String(region || '').toLowerCase().replace(/,.*$/, '').replace(/\s+(county|city|town|village|borough|cdp)$/, '').trim() + '|' + String(st || '').toLowerCase();
  // County key that KEEPS the suffix, so independent cities don't collide with their namesake
  // county. Byte-identical to rfCountyKey in fetch-market.mjs / refresh-market.mjs.
  const rfCountyKey = (region, st) => String(region || '').toLowerCase().replace(/,.*$/, '').replace(/\s+/g, ' ').trim() + '|' + String(st || '').toLowerCase();
  let MARKET = {}, PLACESX = {}, COUNTY2CBSA = {}, CBSA_NAME = {}, ZORI_BY_CBSA = {}, ZHVI_FIPS_OK = false;
  try {
    MARKET = JSON.parse(readFileSync(_resolve(GEN, 'market.json'), 'utf8'));
    PLACESX = JSON.parse(readFileSync(_resolve(__dirname, '.master-crosswalk/crosswalk-places.json'), 'utf8'));
    const cbx = JSON.parse(readFileSync(_resolve(__dirname, '.master-crosswalk/crosswalk-cbsa.json'), 'utf8'));
    COUNTY2CBSA = cbx.county2cbsa || {}; CBSA_NAME = cbx.cbsa_name || {};
    // ZORI metro name "City, ST" -> key; CBSA title "City-...-..., ST" -> same key; join to cbsa code
    const metroKey = (nm) => { const [c, st] = String(nm).split(',').map((x) => (x || '').trim()); return st ? c.toLowerCase() + '|' + st.toLowerCase().split('-')[0] : null; };
    const cbsaKey = (t) => { const [c, st] = String(t).split(',').map((x) => (x || '').trim()); return st ? c.split('-')[0].toLowerCase() + '|' + st.split('-')[0].toLowerCase() : null; };
    const zoriByKey = {}; for (const r of Object.values(MARKET.metros || {})) { const k = metroKey(r.name); if (k && r.zori != null) zoriByKey[k] = r.zori; }
    for (const [code, title] of Object.entries(CBSA_NAME)) { const k = cbsaKey(title); if (k && zoriByKey[k] != null) ZORI_BY_CBSA[code] = zoriByKey[k]; }
    ZHVI_FIPS_OK = Object.keys(MARKET.zhviCountyFips || {}).length > 0;
    console.log(`MARKET: ${Object.keys(MARKET.redfinCity || {}).length} city + ${Object.keys(MARKET.redfinCountyFull || MARKET.redfinCounty || {}).length} county prices; ${Object.keys(ZORI_BY_CBSA).length} CBSA rents; ZHVI ${Object.keys(MARKET.zhviCity || {}).length} city + ${Object.keys(MARKET.zhviCounty || {}).length} county values`);
  } catch (e) { console.log('MARKET: market.json/crosswalk not found — bundles built without overlay (' + e.message + ')'); }
  const buildMarket = (gid, cleanName, level, st) => {
    const abbr = FIPS_USPS[st] || ''; const cbsa = level === 'place' ? (PLACESX[gid] && PLACESX[gid].cbsa) : (COUNTY2CBSA[gid] && COUNTY2CBSA[gid].cbsa);
    const rent = cbsa ? (ZORI_BY_CBSA[cbsa] ?? null) : null;
    const pk = mNormKey(cleanName, abbr);
    // Counties: exact full-name match first (separates "Fairfax city" from "Fairfax County"),
    // then the suffix-stripped map — which fetch-market has already pruned of ambiguous keys,
    // so this fallback can widen coverage but can no longer return the wrong county's price.
    const pr = level === 'place'
      ? (MARKET.redfinCity && MARKET.redfinCity[pk])
      : ((MARKET.redfinCountyFull && MARKET.redfinCountyFull[rfCountyKey(cleanName, abbr)]) || (MARKET.redfinCounty && MARKET.redfinCounty[pk]));
    // ZHVI: modeled typical home VALUE — its own field, never a fallback for the Redfin
    // closed-sale price. Counties join on exact GEOID. The name key is NOT safe at county level
    // (mNormKey strips the "county"/"city" suffix, so "St. Louis city" and "St. Louis County"
    // collide), so only fall back to it if the FIPS map is empty — i.e. the upstream file lost
    // its FIPS columns — rather than per-county.
    const hv = level === 'place'
      ? (MARKET.zhviCity && MARKET.zhviCity[pk])
      : (ZHVI_FIPS_OK ? MARKET.zhviCountyFips[gid] : (MARKET.zhviCounty && MARKET.zhviCounty[pk]));
    if (rent == null && !pr && !hv) return null;
    return { rent, rentAsOf: (MARKET.asOf && MARKET.asOf.zori) || null, price: pr ? pr.price : null, priceAsOf: pr ? pr.period : null, hval: hv ? hv.hval : null, hvalAsOf: hv ? hv.hvalAsOf : null, cbsaTitle: cbsa ? (CBSA_NAME[cbsa] || null) : null };
  };

  mkdirSync(_resolve(OUT, 'states'), { recursive: true });
  const placeIndex = [], countyIndex = [];
  const summary = { places: {}, counties: {} };
  let stateName = {};
  const sj = await pull('B19013', 'state:*', null);
  const sh = sj[0], sni = sh.indexOf('NAME'), ssi = sh.indexOf('state');
  for (const row of sj.slice(1)) stateName[row[ssi]] = row[sni];

  console.log(`\nBuilding ${STATES.length} states — ${PLACE_KEEP.size} profiled places + all counties.\n`);
  let done = 0;
  for (const st of STATES) {
    const bundle = { places: {}, counties: {} };
    for (const level of ['place', 'county']) {
      // pull all tables for this level+state in parallel, merge by geoid
      const results = await mapLimit(TABLES, CONCURRENCY, (t) => pullLevel(t, level, st));
      const merged = new Map();
      for (const m of results) {
        for (const [gid, { name, vars }] of m) {
          if (!merged.has(gid)) merged.set(gid, { name, vars: {} });
          Object.assign(merged.get(gid).vars, vars);
        }
      }
      for (const [gid, { name, vars }] of merged) {
        const model = buildModel(vars);
        if (model.tenure.total < 1) continue;
        model.chas = CHAS[gid] || null;
        model.ami = buildAmi(gid, level);
        model.market = buildMarket(gid, stripState(name), level, st);
        const tgt = level === 'place' ? bundle.places : bundle.counties;
        tgt[gid] = { name: stripState(name), model };
        (level === 'place' ? placeIndex : countyIndex).push({ geoid: gid, name: stripState(name), state_fips: st, state_name: stateName[st] || null });
        (level === 'place' ? summary.places : summary.counties)[gid] = summarize(model);
      }
    }
    writeFileSync(_resolve(OUT, `states/${st}.json`), JSON.stringify(bundle));
    done++;
    console.log(`[${String(done).padStart(2)}/${STATES.length}] ${stateName[st] || st}: ${Object.keys(bundle.places).length} places, ${Object.keys(bundle.counties).length} counties`);
  }

  placeIndex.sort((a, b) => a.name.localeCompare(b.name));
  countyIndex.sort((a, b) => a.name.localeCompare(b.name));
  writeFileSync(_resolve(OUT, 'index.json'), JSON.stringify({
    vintage: 'ACS 2020-2024 5-year', generated_states: STATES,
    places: placeIndex, counties: countyIndex,
  }));

  writeSummary(summary);
  if (amiMiss) console.log(`HUD AMI: ${amiMiss} geographies had no county match — workforce band omitted for those.`);

  console.log(`\nWrote ${STATES.length} state bundles, ${placeIndex.length} places + ${countyIndex.length} counties to index.`);
  console.log(`Summary: ${summary.counties_count} ranked counties, ${summary.places_count} ranked places.`);
}
run().catch((e) => { console.error(e); process.exit(1); });
